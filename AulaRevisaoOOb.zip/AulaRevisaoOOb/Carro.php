<?php

include_once("Veiculo.php");

class Carro extends Veiculo {

    private $potencia;

    function __construct($cor, $modelo, $potencia) {
        parent::__construct($cor, $modelo);
        $this->potencia = $potencia;

    }

    function acelerar($i)
    {
        echo $this->modelo . " vrumm" . "* " . $this->potencia . "<br><br>";
    }
        

    }




