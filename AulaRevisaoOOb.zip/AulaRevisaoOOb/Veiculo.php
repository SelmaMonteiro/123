<?php

class Veiculo {

    public $modelo;
    public $cor;
    private $velocidade = 0;

    function __construct($cor, $modelo) {

        $this->cor = $cor;
        $this->modelo = $modelo;

    }

    function get_velocidade() {
        return $this->velocidade;
    }


function acelerar($i) {
    echo $this->modelo . "  vrumm<br>";
}
        
    }
