<?php

include_once("Veiculo.php");
include_once("Moto.php");
include_once("Carro.php");

$ferr = new Carro("vermelho", "ferrari", 100);
$fuscPreto = new Carro("preto", "fuscao", 50);
$fuscAzul = new Carro("azul", "fuca", 10);

echo "<span>Ferrari Vel:" . $ferr->get_velocidade() . "</span><br>";
echo "<span>FuscAzul Vel:" . $fuscAzul->get_velocidade() . "<span></span><br>";
echo "<span>FuscPreto Vel:" . $fuscPreto->get_velocidade() . "<span></span><br>";

//aqui é tipo nossa largada
//o pisao maximo do acelerador é 10;

$ferr->acelerar(10);
$fuscPreto->acelerar(10);
$fuscAzul->acelerar(10);